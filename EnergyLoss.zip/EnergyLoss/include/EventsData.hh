#ifndef Events_Data_H
#define Events_Data_H

#include "Rtypes.h"	//Basic types used by ROOT.

class EventsData
{
public:
  EventsData()
  {
    InitPx = 0.0;
    InitPy = 0.0;
    InitPz = 0.0;
    Mass = 0.0;
    Energy = 0.0;
//    InitEnergy = 0.0;
//    FinalEnergy = 0.0;
//    ScatterAngle = 0.0;
  }
  virtual ~EventsData(){;}

  Double_t InitPx;
  Double_t InitPy;
  Double_t InitPz;
  Double_t Mass;
  Double_t Energy;
//  Float_t InitEnergy;
//  Float_t FinalEnergy;
//  Float_t ScatterAngle;

private:
};

#endif
