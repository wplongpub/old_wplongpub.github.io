#ifndef ExN01MagneticField_H
#define ExN01MagneticField_H

#include "G4UniformMagField.hh"

class G4FieldManager;

class ExN01MagneticField:public G4UniformMagField
{
public:
	ExN01MagneticField(G4ThreeVector);	// The Value of the field
	ExN01MagneticField();	// A Zero field
	~ExN01MagneticField();

	//Set the field (fieldValue,0,0)
	void SetMagFieldValue(G4double fieldValue);
	void SetMagFieldValue(G4ThreeVector fieldVector);

	G4ThreeVector GetConstantFieldValue();

protected:
	// Find the global Field Manager
	G4FieldManager* GetGlobalFieldManager();
};

#endif
