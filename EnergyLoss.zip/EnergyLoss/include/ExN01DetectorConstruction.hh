#ifndef ExN01DetectorConstruction_H
#define ExN01DetectorConstruction_H 1

class G4LogicalVolume;
class G4VPhysicalVolume;

#include "G4VUserDetectorConstruction.hh"
#include "ExN01MagneticField.hh"
#include "ExN01DetectorMessenger.hh"

class ExN01DetectorMessenger;

class ExN01DetectorConstruction:public G4VUserDetectorConstruction
{
public:
	ExN01DetectorConstruction();
	~ExN01DetectorConstruction();

	G4VPhysicalVolume* Construct();

	void SetMagField(G4double);

	const G4VPhysicalVolume* GetSi()	{return SiBox_phys;};//add 06-02

private:
	// Logical Volumes
	G4LogicalVolume* experimentalBox_log;
	G4LogicalVolume* PtBox_log;
	G4LogicalVolume* SiBox_log;
	G4LogicalVolume* PlBox_log;

	// Physical Volumes
	G4VPhysicalVolume* experimentalBox_phys;
	G4VPhysicalVolume* PtBox_phys;
	G4VPhysicalVolume* SiBox_phys;
	G4VPhysicalVolume* PlBox_phys;

	ExN01MagneticField* fpMagField;

	ExN01DetectorMessenger* detectorMessenger;
};

#endif
