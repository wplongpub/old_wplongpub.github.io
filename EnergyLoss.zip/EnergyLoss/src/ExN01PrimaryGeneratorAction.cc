#include "ExN01PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "globals.hh"

#include "Randomize.hh"

ExN01PrimaryGeneratorAction::ExN01PrimaryGeneratorAction()
{
  G4int n_particle = 1;
  particleGun1 = new G4ParticleGun(n_particle);

  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4String particleName;

  particleGun1->SetParticleDefinition(particleTable->FindParticle(particleName="mu-"));
//  particleGun1->SetParticleDefinition(particleTable->FindParticle(particleName="gamma"));
//  particleGun1->SetParticleDefinition(particleTable->FindParticle(particleName="e-"));

//  particleGun1->SetParticleEnergy(setEnergy*MeV);
  particleGun1->SetParticlePosition(G4ThreeVector(0.0,0.0,-1.*cm));
}

ExN01PrimaryGeneratorAction::~ExN01PrimaryGeneratorAction()
{
  delete particleGun1;
}

void ExN01PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
  G4ThreeVector v(0.0,0.0,1.0);
/*
  G4double randnum = G4UniformRand();
  if(randnum < 0.00611)
    particleGun1->SetParticleEnergy(.031*MeV);
  else if(randnum < 0.14864)
    particleGun1->SetParticleEnergy(.035*MeV);
  else if(randnum < 0.16125)
    particleGun1->SetParticleEnergy(.053*MeV);
  else if(randnum < 0.18017)
    particleGun1->SetParticleEnergy(.0796*MeV);
  else if(randnum < 0.39459)
    particleGun1->SetParticleEnergy(.081*MeV);
  else if(randnum < 0.43873)
    particleGun1->SetParticleEnergy(.276*MeV);
  else if(randnum < 0.55225)
    particleGun1->SetParticleEnergy(.303*MeV);
  else if(randnum < 0.94324)
    particleGun1->SetParticleEnergy(.356*MeV);
  else
    particleGun1->SetParticleEnergy(.383*MeV);
*/
//  G4double randnum = G4UniformRand();
//  G4double setEnergy = 10.+10000000.*randnum;
  G4double setEnergy = 19847.1;

  particleGun1->SetParticleEnergy(setEnergy*MeV);
  particleGun1->SetParticleMomentumDirection(v);
  particleGun1->GeneratePrimaryVertex(anEvent);
}
