#include "ExN01DetectorConstruction.hh"
#include "ExN01MagneticField.hh"
#include "ExN01DetectorMessenger.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
//#include "PhysicalConstants.hh"
#include "globals.hh"

#include "ExN01TrackerSD.hh"
#include "G4SDManager.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

ExN01DetectorConstruction::ExN01DetectorConstruction()
  :  experimentalBox_log(0),SiBox_log(0),
     experimentalBox_phys(0),SiBox_phys(0),
     fpMagField(0)
{
  fpMagField = new ExN01MagneticField();
  detectorMessenger = new ExN01DetectorMessenger(this);
}

ExN01DetectorConstruction::~ExN01DetectorConstruction()
{
  delete fpMagField;
  delete detectorMessenger;
}

G4VPhysicalVolume* ExN01DetectorConstruction::Construct()
{
  //--------------------------------------------- materials

  G4double a;
  G4double z;
  G4double density;
  G4double pressure;
  G4double temperature;
  G4int nel;

  density = universe_mean_density;	//from PhysicalConstants.hh
//  pressure = 1.e-19*pascal;
//  temperature = 0.1*kelvin;
  pressure = 1.013e5*pascal;
  temperature = 298.0*kelvin;

  G4Material* Vacuo =
  new G4Material("Galactic",z=1.,a=1.01*g/mole,density,
		kStateGas,temperature,pressure);
  //Air
  G4Element* N = new G4Element("Nitrogen", "N", z=7., a= 14.01*g/mole);
  G4Element* O = new G4Element("Oxygen"  , "O", z=8., a= 16.00*g/mole);

  G4Material* Air = new G4Material("Air", density= 1.29*mg/cm3, nel=2);
  Air->AddElement(N, 70*perCent);
  Air->AddElement(O, 30*perCent);
/*
  G4Material* Pt =
  new G4Material("Platinum",z=72.,a=195.08*g/mole,density=21.45*g/cm3);
*/
  G4Material* Graphite =
  new G4Material("Graphite",z=6.,a=12.0107*g/mole,density=2.2*g/cm3);

  G4Material* Silicon =
  new G4Material("Silicon",z=14.,a=28.09*g/mole,density=2.329*g/cm3);

  //Plastic
  G4Element* C = new G4Element("Carbon","C",z=6,a=12.01*g/mole);
  G4Element* H = new G4Element("Hydrogen","H",z=1.,a=1*g/mole);

  G4Material *Plastic =
  new G4Material("Plastic",density=1.032*g/cm3,nel=2);
  Plastic->AddElement(C,91.5*perCent);
  Plastic->AddElement(H,8.5*perCent);

  //Pb
  G4Material* Pb = new G4Material("Lead",z=82.,a=207.20*g/mole,density = 11.34*g/cm3);

  //-------------------------------------------- volumes
  //------------------------ experimental box (world volume)

  G4double expBox_x = 1.*cm;
  G4double expBox_y = 1.*cm;
  G4double expBox_z = 1.*cm;
  G4Box* experimentalBox_box
    = new G4Box("expBox_box",expBox_x,expBox_y,expBox_z);
  experimentalBox_log = new G4LogicalVolume(experimentalBox_box,
					    Vacuo, "expBox_log", 0,0,0);
  experimentalBox_phys = new G4PVPlacement(0,G4ThreeVector(),
					   experimentalBox_log,"expBox",0,false,0);

  //---------------------- target_2

  G4double SiBox_x=0.15*cm;
  G4double SiBox_y=0.15*cm;
  G4double SiBox_z=0.0014*cm;
  G4Box* SiBox_box
    = new G4Box("SiBox_box",SiBox_x,SiBox_y,SiBox_z);
  SiBox_log = new G4LogicalVolume(SiBox_box,Pb,"SiBox_log",0,0,0);

  G4double SiBoxPos_x=0.*cm;
  G4double SiBoxPos_y=0.*cm;
  G4double SiBoxPos_z=0.0375*cm;
  SiBox_phys = new G4PVPlacement(0,
		G4ThreeVector(SiBoxPos_x,SiBoxPos_y,SiBoxPos_z),
		SiBox_log,"SiBox",experimentalBox_log,false,0);
  //------------------------------------------------
  // Sensitive detectors
  //------------------------------------------------

  G4SDManager* SDman = G4SDManager::GetSDMpointer();

  G4String trackerChamberSDname = "ExN01/TrackerChamberSD";
  ExN01TrackerSD* aTrackerSD = new ExN01TrackerSD(trackerChamberSDname);
  SDman->AddNewDetector(aTrackerSD);
  SiBox_log->SetSensitiveDetector(aTrackerSD);

//--------- Visualization attributes -------------------------------

  G4VisAttributes* TargetVisAtt_2 = new G4VisAttributes(G4Colour(0.0,1.0,0.0));
  SiBox_log->SetVisAttributes(TargetVisAtt_2);

  G4VisAttributes* TargetVisAtt_W = new G4VisAttributes(G4Colour(0.0,0.0,0.0));
  experimentalBox_log->SetVisAttributes(TargetVisAtt_W);

  return experimentalBox_phys;
}

void ExN01DetectorConstruction::SetMagField(G4double fieldValue)
{
  fpMagField->SetMagFieldValue(fieldValue);
}
