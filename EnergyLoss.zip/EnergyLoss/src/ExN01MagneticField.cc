#include "ExN01MagneticField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"

ExN01MagneticField::ExN01MagneticField()
  : G4UniformMagField(G4ThreeVector())
{
  GetGlobalFieldManager()->SetDetectorField(this);
  GetGlobalFieldManager()->CreateChordFinder(this);
}

ExN01MagneticField::ExN01MagneticField(G4ThreeVector fieldVector)
  : G4UniformMagField(fieldVector)
{
  GetGlobalFieldManager()->SetDetectorField(this);
  GetGlobalFieldManager()->CreateChordFinder(this);
}

ExN01MagneticField::~ExN01MagneticField()
{
}

// Set the value of the Global Field to fieldValue along X
//
void ExN01MagneticField::SetMagFieldValue(G4double fieldValue)
{
  SetMagFieldValue(G4ThreeVector(fieldValue,0,0));
}

// Set the value of the Global Field
//
void ExN01MagneticField::SetMagFieldValue(G4ThreeVector fieldVector)
{
  // Find the Field Manager for the global field
  G4FieldManager* fieldMgr = GetGlobalFieldManager();

  if(fieldVector!=G4ThreeVector(0.,0.,0.))
  {
    SetFieldValue(fieldVector);
    fieldMgr->SetDetectorField(this);
  }
  else
  {
    G4MagneticField* magField = 0;
    fieldMgr->SetDetectorField(magField);
  }
}

G4FieldManager* ExN01MagneticField::GetGlobalFieldManager()
{
  return G4TransportationManager::GetTransportationManager()->GetFieldManager();
}
