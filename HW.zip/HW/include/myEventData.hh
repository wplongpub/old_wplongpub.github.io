#ifndef EventData_h
#define EventData_h 1

#include "/grid/software/ROOT/5.34.26/gcc-4.8/include/Rtypes.h" // basic type used by ROOT.

class EventData
{
public:
  EventData()
  {
    InitPx = 0.0;
    InitPy = 0.0;
    InitPz = 0.0;
    Mass = 0.0;
    Energy = 0.0;
  }
  
  virtual ~EventData()
  {}

  Double_t InitPx;
  Double_t InitPy;
  Double_t InitPz;
  Double_t Mass;
  Double_t Energy;
};

#endif
