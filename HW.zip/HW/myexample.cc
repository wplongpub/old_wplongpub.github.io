#include "myDetectorConstruction.hh"
#include "myPrimaryGeneratorAction.hh"
#include "myRunAction.hh"
#include "myEventData.hh"
#include "myEventAction.hh"
#include "mySteppingAction.hh"

#include "FTFP_BERT.hh"

#ifdef G4MULTITHREADED
#include "G4MTRunManager.hh"
#else
#include "G4RunManager.hh"
#endif

#include "G4UImanager.hh"
#include "G4UIcommand.hh"

#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"

// include ROOT class
#include "TFile.h"
#include "TTree.h"


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......   

// ROOT file generator
//
TTree* myTree = new TTree("myTree", "my simple tree");
EventsData myEventData;

int main(int argc, char** argv)
{
  // Creat a new TFile
  TFile* f= new TFile("test.root", "recreate");
 
  // TTree SetBranch
  myTree->Branch("InitPx", &myEventData.InitPx, "InitPx/D");
  myTree->Branch("InitPy", &myEventData.InitPy, "InitPy/D");
  myTree->Branch("InitPz", &myEventData.InitPz, "InitPz/D");
  myTree->Branch("Mass", &myEventData.Mass, "Mass/D");
  myTree->Branch("Energy", &myEventData.Energy, "Energy/D");

  // Detect interactive mode (if no arguments) and define UI session 
  //
  G4UIExecutive* ui = 0;
  if ( argc == 1 ) {
    ui = new G4UIExecutive(argc, argv);
  }

  // Construct the default run manager
  //
#ifdef G4MULTITHREADED
  G4MTRunManager* runManager = new G4MTRunManager;
#else
  G4RunManager* runManager = new G4RunManager;
#endif

  // Set mandatory initialization classes
  //
  // Detector construction
  myDetectorConstruction* detConstruction = new myDetectorConstruction();
  runManager->SetUserInitialization(detConstruction);

  // Physics list
  G4VModularPhysicsList* physicsList = new FTFP_BERT;
  runManager->SetUserInitialization(physicsList);

  // User action initialization
  runManager->SetUserAction(new myPrimaryGeneratorAction);
  runManager->SetUserAction(new myRunAction);
  myEventAction* eventAction = new myEventAction;
  runManager->SetUserAction(eventAction);
  runManager->SetUserAction(new mySteppingAction(detConstruction, eventAction));

  runManager->Initialize();


  // Initialize visualization
  //
  G4VisManager* visManager = new G4VisExecutive;
  // G4VisExecutive can take a verbosity argument - see /vis/verbose guidance.
  // G4VisManager* visManager = new G4VisExecutive("Quiet");
  visManager->Initialize();

  // Get the pointer to the User Interface manager
  G4UImanager* UImanager = G4UImanager::GetUIpointer();

  // Process macro or start UI session
  //
  if ( macro.size() ) {
    // batch mode
    G4String command = "/control/execute ";
    G4String fileName = argv[1];
    UImanager->ApplyCommand(command+fileName);
  }
  else{
    // interactive mode
    UImanager->ApplyCommand("/control/execute init_vis.mac");
    ui->SessionStart();
    delete ui;
  }

  myTree->Write();

  // Job termination
  // Free the store: user actions, physics_list and detector_description are owned and deleted by the run manager, so they should not be deleted in the main() program !
  delete myTree;
  delete f;

  delete visManager;
  delete runManager;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OO\ooo.....                                                                
