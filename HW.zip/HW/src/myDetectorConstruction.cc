#include "myDetectorConstruction.hh"

#include "G4Mateerial.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4AutoDelete.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo...... 

myDetectorConstruction::myDetectorConstruction()
  : G4UserDetectorConstruction(),
    fAbsorberPV(0),
    fCheckOverlaps(true)
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

myDetectorConstruction::~myDetectorConstruction()
{ 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* myDetectorConstruction::Construct()
{
  // Define materials
  DefineMaterials();

  // Define volumes
  return DefineVolumes();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void myDetectorConstruction::DefineMaterials()
{
  // Iron material defined using NIST Manager
  G4NistManager* nistManager = G4NistManager::Instance();
  nistManger->FindOrBuildMaterial("G4_Fe");

  // Vacuumnn
  new G4Material("Galactic", z=1., a=1.01*g/mole, universe_mean_density, kStateGas, 2.73*kelvin, 3.e-18*pascal);

  // Print materials
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
G4VPhysicalVolume* myDetectorConstruction::DefineVolumes()
{
  // Geometry parameters
  G4double absoSizeXY = 10.*cm;
  G4double absoThickness = 10.*cm;

  G4double worldSizeXY = 1.2 * absoSizeXY;
  G4double worldSizeZ = 1.2 * absoThickness;

  // Get Materials
  G4Material* defaultMaterial = G4Material::GetMaterial("Galactic");
  G4Material* absorberMaterial = G4Material::GetMaterial("G4_Fe");

  //
  // World
  //
  G4VSolid* worldS = new G4Box("World", // its name
			       worldSizeXY/2, worldSizeXY/2, worldSizeZ/2); // its size

  G4LogicalVolume* worldLV
    = new G4LogicalVolume(
			  worldS, // its solid
			  defaultMaterial, // its material
			  "World"); // its name

  G4VPhysicalVolume* worldPV
    = new G4PVPlacement(
			0, // no rotation
			G4ThreeVector(), // at (0,0,0)
			worldLV, // its logical volume

			"World", // its name
			0, // its mother volume
			false, // no boolean operation
			0, // copy number
			fCheckOverlaps); // checking overlaps

  //
  // Absorber
  //
  G4VSolid* absorberS = new G4Box("Abso", // its name
				  absoSizeXY/2, absoSizeXY/2, absoThickness/2); // its size
 
  G4LogicalVolume* absorberLV
    = new G4LogicalVolume(
			  absorberS, // its solid
			  absorberMaterial, // its material
			  "Abso"); // its name

  fAbsorberPV
    = new G4PVPlacement(
			0, // no rotation
			G4ThreeVector(0., 0., 0.), // its position
			absorberLV, // its logical volume
		       
			"Abso", // its name
			worldLV, // its mother volume
			false, // no boolean operation
			0, // copy number
			fCheckOverlaps); // checking overlaps
 

  //
  // print parameters
  //
  G4cout
    << G4endl
    << "------------------------------------------------------------" << G4endl
    << "---> The calorimeter is " 
    << absoThickness/mm << "mm of " << absorberMaterial->GetName()
    << "------------------------------------------------------------" << G4endl;

  //
  // Visualization attributes
  //
  worldLV->SetVisAttributes (G4VisAttributes::Invisible);
 
  G4VisAttributes* simpleBoxVisAtt = new G4VisAttributes(G4Colour(1.0, 1.0, 1.0));
  simpleBoxVisAtt->SetVisibility(true);
  absoLV->SetVisAttributes(simpleBoxVisAtt);
 
  //
  // Always return the physical World
  //

  return worldPV;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
