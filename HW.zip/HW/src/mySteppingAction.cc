#include "mySteppingAction.hh"
#include "myDetectorConstruction.hh"
#include "myEventAction.hh"

#include "G4SteppingManager.hh"
#include "G4Step.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

mySteppingAction::mySteppingAction(
				   const myDetectorConstruction* detectorConstruction, 
				   myEventAction* eventAction)
  :G4UserSteppingAction(),
   fDetConstruction(detectorConstruction),
   fEventAction(eventAction)
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

mySteppingAction::~mySteppingAction()
{
}

void mySteppingAction::UserSteppingAction(const G4Step* step)
{
  //  Collect energy and track length step by step

  // get volume of the current step
  G4VPhysicalVolume* volume 
    = step->GetPreStepPoint()->GetTouchableHandle()->GetVolume();

  // energy deposit
  G4double edep = step->GetTotalEnergyDeposit();

  if ( volume == fDetConstruction->GetAbsorberPV() )
    fEventAction->AddAbs(edep);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......


