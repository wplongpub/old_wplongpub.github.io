#include "myEventAction.hh"
#include "myEventData.hh"

#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4TrajectoryContainer.hh"
#include "G4ios.hh"

// add myTTree
#include "TTree.h"
#include "G4HCofThisEvent.hh"

extern TTree* myTree;
extern EventData myEventData;


myEventAction::myEventAction()
  : G4UserEventAction(),
    fEnergyAbs(0.),
    fTrackLAbs(0.),
{}

myEventAction::~myEventAction()
{}

void myEventAction::BeginOfEventAction(const G4Event* /*event*/)
{
  // initialization per event
  fEnergyAbs = 0.;
  fTrackLAbs = 0.;
}


void myEventAction::EndOfEventAction(const G4Event* event)
{
  G4int event_id = event->GetEventID();
  
  // get number of stored trajectories
  //
  G4TrajectoryContainer* trajectoryContainer = event->GetTrajectorContianer();
  G4int n_trajectories = 0;

  if (trajectoryContainer) 
    n_trajectories = trajectoryContainer->entries();

  // periodic printing
  //
  if (event_id < 100 || event_id%100 == 0) {
    G4cout << ">>> Event " << evt->GetEventID() << G4endl;
    G4cout << "   " << n_trajectories 
           << " trajectories stored in this event. " << G4endl;
  }


  // to get initial information
  if (fEnergyAbs > 0.){
    G4PrimaryVertex* myVertex = event->GetPrimaryVertex(0);
    G4PrimaryParticle* myPrimaryParticle = myVertex->GetPrimary(0);
    G4HCofThisEvent* hc = event->GetHCofThisEvent();

    G4double myInitPx = myPrimaryParticle->GetPx();
    G4double myInitPy = myPrimaryParticle->GetPy();
    G4double myInitPz = myPrimaryParticle->GetPz();
    G4double NbOfColl = hc->GetNumberOfCollections();

    myEventData.InitPx = myInitPx;
    myEventData.InitPy = myInitPy;
    myEventData.InitPx = myInitPz;
    myEventData.Mass = NbOfColl;
    myEventData.Energy = fEnergyAbs;

    myTree->Fill();
  }
}
