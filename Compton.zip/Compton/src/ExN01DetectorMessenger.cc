#include "ExN01DetectorMessenger.hh"

#include "ExN01DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "globals.hh"

ExN01DetectorMessenger::ExN01DetectorMessenger(ExN01DetectorConstruction* myDet)
:myDetector(myDet)
{
  N01Dir = new G4UIdirectory("/N01/");
  N01Dir->SetGuidance("UI commands specific to this example.");

  detDir = new G4UIdirectory("/N01/det/");
  detDir->SetGuidance("detector control.");

  FieldCmd = new G4UIcmdWithADoubleAndUnit("/N01/det/setField",this);
  FieldCmd->SetGuidance("Define magnetic field.");
  FieldCmd->SetGuidance("Magnetic field will be in X direction.");
  FieldCmd->SetParameterName("Bx",false);
  FieldCmd->SetUnitCategory("Magnetic flux density");
  FieldCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
}

ExN01DetectorMessenger::~ExN01DetectorMessenger()
{
  delete FieldCmd;
  delete N01Dir;
  delete detDir;
}

void ExN01DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if(command==FieldCmd)
  {
	myDetector->SetMagField(FieldCmd->GetNewDoubleValue(newValue));
  }
}
