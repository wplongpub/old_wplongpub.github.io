#ifndef ExN01PhysicsList_h
#define ExN01PhysicsList_h 1

#include "G4VUserPhysicsList.hh"
#include "globals.hh"

class ExN01PhysicsList:public G4VUserPhysicsList
{
public:
	ExN01PhysicsList();
	~ExN01PhysicsList();
protected:
	//Construct particle and physics process
	void ConstructParticle();
	void ConstructProcess();
	void SetCuts();
	void ConstructLeptons();
	void ConstructBosons();
	void ConstructMesons();
	void ConstructBaryons();
	void ConstructEM();
	void AddStepMax();
};

#endif
