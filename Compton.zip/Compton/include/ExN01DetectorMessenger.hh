#ifndef ExN01DetectorMessenger_h
#define ExN01DetectorMessenger_h 1

#include "G4UImessenger.hh"
#include "globals.hh"

class G4UIdirectory;
class G4UIcmdWithADoubleAndUnit;
class ExN01DetectorConstruction;

class ExN01DetectorMessenger:public G4UImessenger
{
public:
	ExN01DetectorMessenger(ExN01DetectorConstruction*);
	~ExN01DetectorMessenger();

	void SetNewValue(G4UIcommand*,G4String);

private:
	ExN01DetectorConstruction* myDetector;

	G4UIdirectory* N01Dir;
	G4UIdirectory* detDir;
	G4UIcmdWithADoubleAndUnit* FieldCmd;
};

#endif
