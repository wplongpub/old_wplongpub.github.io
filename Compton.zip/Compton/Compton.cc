// -----------------------------------------------------------------------
//		GEANT 4 - exampleN01:Rutherford Scatter
// -----------------------------------------------------------------------

#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4UIterminal.hh"
#include "G4VisExecutive.hh"

#include "ExN01DetectorConstruction.hh"
#include "ExN01PhysicsList.hh"
#include "ExN01PrimaryGeneratorAction.hh"

#include "ExN01RunAction.hh"
#include "ExN01EventAction.hh"
#include "ExN01SteppingAction.hh"
#include "ExN01SteppingVerbose.hh"

//added by xizhao,2013.10.08
#include "TFile.h"
#include "TTree.h"
#include "EventsData.hh"

TTree *myTree = new TTree("myTree","my simple tree");
EventsData myEventsData;

int main()
{
  //added by xizhao,2013.10.08
  //create a new TFile
  TFile *f = new TFile("test.root","recreate");
  //TTree SetBranch
  myTree->Branch("InitPx",&myEventsData.InitPx,"InitPx/D");
  myTree->Branch("InitPy",&myEventsData.InitPy,"InitPy/D");
  myTree->Branch("InitPz",&myEventsData.InitPz,"InitPz/D");
  myTree->Branch("Mass",&myEventsData.Mass,"Mass/D");

  // User Verbose output class
  //
  G4VSteppingVerbose* verbosity = new ExN01SteppingVerbose;
  G4VSteppingVerbose::SetInstance(verbosity);

  // Run manager
  //
  G4RunManager* runManager = new G4RunManager;

//  G4VUserDetectorConstruction* detector = new ExN00DetectorConstruction;
  ExN01DetectorConstruction* detector = new ExN01DetectorConstruction;
//  G4double TBValue = 1.0*tesla;
//  detector->SetMagField(TBValue);
  runManager->SetUserInitialization(detector);

  G4VUserPhysicsList* physics = new ExN01PhysicsList;
  runManager->SetUserInitialization(physics);

  // User Action classes
  //
//  G4VUserPrimaryGeneratorAction* gen_action = new ExN01PrimaryGeneratorAction(detector);
  G4VUserPrimaryGeneratorAction* gen_action = new ExN01PrimaryGeneratorAction();
  runManager->SetUserAction(gen_action);
  //
  G4UserRunAction* run_action = new ExN01RunAction;
  runManager->SetUserAction(run_action);
  //
  G4UserEventAction* event_action = new ExN01EventAction;
  runManager->SetUserAction(event_action);
  //
  G4UserSteppingAction* stepping_action = new ExN01SteppingAction;
  runManager->SetUserAction(stepping_action);

  runManager->Initialize();

  G4VisManager* visManager = new G4VisExecutive;
  visManager->Initialize();

  G4UImanager* UI = G4UImanager::GetUIpointer();
  UI->ApplyCommand("/control/execute vis.mac");
//  UI->ApplyCommand("/run/verbose 1");
//  UI->ApplyCommand("/event/verbose 1");
//  UI->ApplyCommand("/tracking/verbose 1");
//  UI->ApplyCommand("/hits/verbose 1");
//  UI->ApplyCommand("/control/execute vis.mac");


  G4UIsession* session = new G4UIterminal();
  session->SessionStart();

  //added by xizhao,2013.10.08
  myTree->Write();
  delete myTree;
  delete f;

  delete runManager;
  delete visManager;
  delete session;

  delete verbosity;

  return 0;
}
