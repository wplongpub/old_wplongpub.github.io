#ifndef ExN09MagneticField_H
#define ExN09MagneticField_H

#include "G4UniformMagField.hh"

class G4FieldManager;

class ExN09MagneticField:public G4UniformMagField
{
public:
	ExN09MagneticField(G4ThreeVector);	// The Value of the field
	ExN09MagneticField();	// A Zero field
	~ExN09MagneticField();

	//Set the field (fieldValue,0,0)
	void SetMagFieldValue(G4double fieldValue);
	void SetMagFieldValue(G4ThreeVector fieldVector);

	G4ThreeVector GetConstantFieldValue();

protected:
	// Find the global Field Manager
	G4FieldManager* GetGlobalFieldManager();
};

#endif
