#ifndef ExN09PhysicsList_h
#define ExN09PhysicsList_h 1

#include "G4VUserPhysicsList.hh"
#include "globals.hh"

class ExN09PhysicsList:public G4VUserPhysicsList
{
public:
	ExN09PhysicsList();
	~ExN09PhysicsList();
protected:
	//Construct particle and physics process
	void ConstructParticle();
	void ConstructProcess();
	void SetCuts();
	void ConstructLeptons();
	void ConstructBosons();
	void ConstructMesons();
	void ConstructBaryons();
	void ConstructEM();
	void AddStepMax();
};

#endif
