#ifndef ExN09DetectorMessenger_h
#define ExN09DetectorMessenger_h 1

#include "G4UImessenger.hh"
#include "globals.hh"

class G4UIdirectory;
class G4UIcmdWithADoubleAndUnit;
class ExN09DetectorConstruction;

class ExN09DetectorMessenger:public G4UImessenger
{
public:
	ExN09DetectorMessenger(ExN09DetectorConstruction*);
	~ExN09DetectorMessenger();

	void SetNewValue(G4UIcommand*,G4String);

private:
	ExN09DetectorConstruction* myDetector;

	G4UIdirectory* N09Dir;
	G4UIdirectory* detDir;
	G4UIcmdWithADoubleAndUnit* FieldCmd;
};

#endif
