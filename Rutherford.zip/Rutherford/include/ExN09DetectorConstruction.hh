#ifndef ExN09DetectorConstruction_H
#define ExN09DetectorConstruction_H 1

class G4LogicalVolume;
class G4VPhysicalVolume;

#include "G4VUserDetectorConstruction.hh"
#include "ExN09MagneticField.hh"
#include "ExN09DetectorMessenger.hh"

class ExN09DetectorMessenger;

class ExN09DetectorConstruction:public G4VUserDetectorConstruction
{
public:
	ExN09DetectorConstruction();
	~ExN09DetectorConstruction();

	G4VPhysicalVolume* Construct();

	void SetMagField(G4double);

private:
	// Logical Volumes
	G4LogicalVolume* experimentalBox_log;
	G4LogicalVolume* PtBox_log;

	// Physical Volumes
	G4VPhysicalVolume* experimentalBox_phys;
	G4VPhysicalVolume* PtBox_phys;

	ExN09MagneticField* fpMagField;

	ExN09DetectorMessenger* detectorMessenger;
};

#endif
