// -----------------------------------------------------------------------
//		GEANT 4 - exampleN09:Rutherford Scatter
// -----------------------------------------------------------------------

#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4UIterminal.hh"
#include "G4VisExecutive.hh"

#include "ExN09DetectorConstruction.hh"
#include "ExN09PhysicsList.hh"
#include "ExN09PrimaryGeneratorAction.hh"

#include "ExN09RunAction.hh"
#include "ExN09EventAction.hh"
#include "ExN09SteppingAction.hh"
#include "ExN09SteppingVerbose.hh"

#include "TFile.h"

int main()
{
  // User Verbose output class
  //
  G4VSteppingVerbose* verbosity = new ExN09SteppingVerbose;
  G4VSteppingVerbose::SetInstance(verbosity);

  // Run manager
  //
  G4RunManager* runManager = new G4RunManager;

//  G4VUserDetectorConstruction* detector = new ExN00DetectorConstruction;
  ExN09DetectorConstruction* detector = new ExN09DetectorConstruction;
//  G4double TBValue = 1.0*tesla;
//  detector->SetMagField(TBValue);
  runManager->SetUserInitialization(detector);

  G4VUserPhysicsList* physics = new ExN09PhysicsList;
  runManager->SetUserInitialization(physics);

  // User Action classes
  //
//  G4VUserPrimaryGeneratorAction* gen_action = new ExN09PrimaryGeneratorAction(detector);
  G4VUserPrimaryGeneratorAction* gen_action = new ExN09PrimaryGeneratorAction();
  runManager->SetUserAction(gen_action);
  //
  G4UserRunAction* run_action = new ExN09RunAction;
  runManager->SetUserAction(run_action);
  //
  G4UserEventAction* event_action = new ExN09EventAction;
  runManager->SetUserAction(event_action);
  //
  G4UserSteppingAction* stepping_action = new ExN09SteppingAction;
  runManager->SetUserAction(stepping_action);

  runManager->Initialize();

  G4VisManager* visManager = new G4VisExecutive;
  visManager->Initialize();

  G4UImanager* UI = G4UImanager::GetUIpointer();
  UI->ApplyCommand("/control/execute vis.mac");
  UI->ApplyCommand("/run/verbose 1");
  UI->ApplyCommand("/event/verbose 1");
  UI->ApplyCommand("/tracking/verbose 1");
  UI->ApplyCommand("/hits/verbose 1");
//  UI->ApplyCommand("/control/execute vis.mac");


  G4UIsession* session = new G4UIterminal();
  session->SessionStart();

  TFile f1("TestRoot.root","RECREATE");
  f1.Close();

  delete runManager;
  delete visManager;
  delete session;

  delete verbosity;

  return 0;
}
