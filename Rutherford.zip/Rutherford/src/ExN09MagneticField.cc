#include "ExN09MagneticField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"

ExN09MagneticField::ExN09MagneticField()
  : G4UniformMagField(G4ThreeVector())
{
  GetGlobalFieldManager()->SetDetectorField(this);
  GetGlobalFieldManager()->CreateChordFinder(this);
}

ExN09MagneticField::ExN09MagneticField(G4ThreeVector fieldVector)
  : G4UniformMagField(fieldVector)
{
  GetGlobalFieldManager()->SetDetectorField(this);
  GetGlobalFieldManager()->CreateChordFinder(this);
}

ExN09MagneticField::~ExN09MagneticField()
{
}

// Set the value of the Global Field to fieldValue along X
//
void ExN09MagneticField::SetMagFieldValue(G4double fieldValue)
{
  SetMagFieldValue(G4ThreeVector(fieldValue,0,0));
}

// Set the value of the Global Field
//
void ExN09MagneticField::SetMagFieldValue(G4ThreeVector fieldVector)
{
  // Find the Field Manager for the global field
  G4FieldManager* fieldMgr = GetGlobalFieldManager();

  if(fieldVector!=G4ThreeVector(0.,0.,0.))
  {
    SetFieldValue(fieldVector);
    fieldMgr->SetDetectorField(this);
  }
  else
  {
    G4MagneticField* magField = 0;
    fieldMgr->SetDetectorField(magField);
  }
}

G4FieldManager* ExN09MagneticField::GetGlobalFieldManager()
{
  return G4TransportationManager::GetTransportationManager()->GetFieldManager();
}
