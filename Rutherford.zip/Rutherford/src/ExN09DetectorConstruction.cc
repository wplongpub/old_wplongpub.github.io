#include "ExN09DetectorConstruction.hh"
#include "ExN09MagneticField.hh"
#include "ExN09DetectorMessenger.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
//#include "PhysicalConstants.hh"
#include "globals.hh"

#include "ExN09TrackerSD.hh"
#include "G4SDManager.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

ExN09DetectorConstruction::ExN09DetectorConstruction()
  :  experimentalBox_log(0),PtBox_log(0),
     experimentalBox_phys(0),PtBox_phys(0),
     fpMagField(0)
{
  fpMagField = new ExN09MagneticField();
  detectorMessenger = new ExN09DetectorMessenger(this);
}

ExN09DetectorConstruction::~ExN09DetectorConstruction()
{
  delete fpMagField;
  delete detectorMessenger;
}

G4VPhysicalVolume* ExN09DetectorConstruction::Construct()
{
  //--------------------------------------------- materials

  G4double a;
  G4double z;
  G4double density;
  G4double pressure;
  G4double temperature;
  G4int nel;

  density = universe_mean_density;	//from PhysicalConstants.hh
  pressure = 1.e-19*pascal;
  temperature = 0.1*kelvin;

  G4Material* Vacuo =
  new G4Material("Galactic",z=1.,a=1.01*g/mole,density,
		kStateGas,temperature,pressure);
  //Air
  G4Element* N = new G4Element("Nitrogen", "N", z=7., a= 14.01*g/mole);
  G4Element* O = new G4Element("Oxygen"  , "O", z=8., a= 16.00*g/mole);

  G4Material* Air = new G4Material("Air", density= 1.29*mg/cm3, nel=2);
  Air->AddElement(N, 70*perCent);
  Air->AddElement(O, 30*perCent);

  G4Material* Pt =
  new G4Material("Platinum",z=72.,a=195.08*g/mole,density=21.45*g/cm3);


  //-------------------------------------------- volumes
  //------------------------ experimental box (world volume)

  G4double expBox_x = 1.5*cm;
  G4double expBox_y = 1.5*cm;
  G4double expBox_z = 1.6*cm;
  G4Box* experimentalBox_box
    = new G4Box("expBox_box",expBox_x,expBox_y,expBox_z);
  experimentalBox_log = new G4LogicalVolume(experimentalBox_box,
					    Vacuo, "expBox_log", 0,0,0);
  experimentalBox_phys = new G4PVPlacement(0,G4ThreeVector(),
					   experimentalBox_log,"expBox",0,false,0);

  //---------------------- target

  G4double PtBox_x=0.1*cm;
  G4double PtBox_y=0.1*cm;
  G4double PtBox_z=0.004*mm;
  G4Box* PtBox_box
    = new G4Box("PtBox_box",PtBox_x,PtBox_y,PtBox_z);
  PtBox_log = new G4LogicalVolume(PtBox_box,Pt,"PtBox_log",0,0,0);
  
  G4double PtBoxPos_x=0.*cm;
  G4double PtBoxPos_y=0.*cm;
  G4double PtBoxPos_z=0.*cm;
  PtBox_phys = new G4PVPlacement(0,
		G4ThreeVector(PtBoxPos_x,PtBoxPos_y,PtBoxPos_z),
		PtBox_log,"PtBox",experimentalBox_log,false,0);

  //------------------------------------------------
  // Sensitive detectors
  //------------------------------------------------

  G4SDManager* SDman = G4SDManager::GetSDMpointer();

  G4String trackerChamberSDname = "ExN09/TrackerChamberSD";
  ExN09TrackerSD* aTrackerSD = new ExN09TrackerSD(trackerChamberSDname);
  SDman->AddNewDetector(aTrackerSD);
  PtBox_log->SetSensitiveDetector(aTrackerSD);

//--------- Visualization attributes -------------------------------

  G4VisAttributes* TargetVisAtt = new G4VisAttributes(G4Colour(1.0,0.0,0.0));
  PtBox_log->SetVisAttributes(TargetVisAtt);

  G4VisAttributes* TargetVisAtt_W = new G4VisAttributes(G4Colour(0.0,0.0,0.0));
  experimentalBox_log->SetVisAttributes(TargetVisAtt_W);

  return experimentalBox_phys;
}

void ExN09DetectorConstruction::SetMagField(G4double fieldValue)
{
  fpMagField->SetMagFieldValue(fieldValue);
}
