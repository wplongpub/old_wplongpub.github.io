#include "ExN09DetectorMessenger.hh"

#include "ExN09DetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "globals.hh"

ExN09DetectorMessenger::ExN09DetectorMessenger(ExN09DetectorConstruction* myDet)
:myDetector(myDet)
{
  N09Dir = new G4UIdirectory("/N09/");
  N09Dir->SetGuidance("UI commands specific to this example.");

  detDir = new G4UIdirectory("/N09/det/");
  detDir->SetGuidance("detector control.");

  FieldCmd = new G4UIcmdWithADoubleAndUnit("/N09/det/setField",this);
  FieldCmd->SetGuidance("Define magnetic field.");
  FieldCmd->SetGuidance("Magnetic field will be in X direction.");
  FieldCmd->SetParameterName("Bx",false);
  FieldCmd->SetUnitCategory("Magnetic flux density");
  FieldCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
}

ExN09DetectorMessenger::~ExN09DetectorMessenger()
{
  delete FieldCmd;
  delete N09Dir;
  delete detDir;
}

void ExN09DetectorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if(command==FieldCmd)
  {
	myDetector->SetMagField(FieldCmd->GetNewDoubleValue(newValue));
  }
}
