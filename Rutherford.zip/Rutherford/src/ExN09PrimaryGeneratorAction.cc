#include "ExN09PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "globals.hh"

ExN09PrimaryGeneratorAction::ExN09PrimaryGeneratorAction()
{
  G4int n_particle = 1;
//  particleGun1 = new G4ParticleGun(n_particle);
  particleGun2 = new G4ParticleGun(n_particle);
//  particleGun3 = new G4ParticleGun(n_particle);

  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4String particleName;
/*
  particleGun1->SetParticleDefinition(particleTable->FindParticle(particleName="geantino"));

  particleGun1->SetParticleEnergy(1.0*GeV);
  particleGun1->SetParticlePosition(G4ThreeVector(0.0,0.0,-1.5*m));
*/
  particleGun2->SetParticleDefinition(particleTable->FindParticle(particleName="alpha"));
  particleGun2->SetParticleEnergy(5.155*MeV);
  particleGun2->SetParticlePosition(G4ThreeVector(0.0,0.0,-1.5*cm));
/*
  particleGun3->SetParticleDefinition(particleTable->FindParticle(particleName="e-"));
  particleGun3->SetParticleEnergy(1.0*GeV);
  particleGun3->SetParticlePosition(G4ThreeVector(0.0,0.0,-1.5*m));
*/
}

ExN09PrimaryGeneratorAction::~ExN09PrimaryGeneratorAction()
{
//  delete particleGun1;
  delete particleGun2;
//  delete particleGun3;
}

void ExN09PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
/*
  G4int i = anEvent->GetEventID() % 3;
  G4ThreeVector v(0.0,0.0,1.0);
  switch(i)
  {
    case 0:
      break;
    case 1:
      v.setY(-0.1);
      break;
    case 2:
      v.setY(0.1);
      break;
  }
*/
//  particleGun1->SetParticleMomentumDirection(v);
//  particleGun1->GeneratePrimaryVertex(anEvent);

  G4ThreeVector v(0.0,0.0,1.0);

  particleGun2->SetParticleMomentumDirection(v);
  particleGun2->GeneratePrimaryVertex(anEvent);

//  particleGun3->SetParticleMomentumDirection(v);
//  particleGun3->GeneratePrimaryVertex(anEvent);
}
